package com.example.memorandum;

import androidx.cardview.widget.CardView;

import com.example.memorandum.Models.Memos;

public interface MemosClickListener {
    void onClick(Memos memos);
    void onLongClick(Memos memos, CardView cardView);
}
