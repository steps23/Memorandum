# Memorandum
 App memo android (progetto universitario corso MobDev)
