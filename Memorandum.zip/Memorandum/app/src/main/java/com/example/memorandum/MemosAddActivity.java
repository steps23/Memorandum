package com.example.memorandum;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Context;
import android.content.Intent;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.example.memorandum.Models.Memos;
import com.google.android.gms.maps.model.LatLng;

import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class MemosAddActivity extends AppCompatActivity {
    EditText editText_title,editText_notes,editText_location;
    ImageView imageView_save;
    Memos memos;
    boolean isOldNote= false;

    DatePickerDialog datePickerDialog;
    TimePickerDialog timePickerDialog;
    Button date_picker_btn,time_btn;
    int hour,minute;
    String time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_memos_add);

        imageView_save = findViewById(R.id.imageView_save);
        editText_title= findViewById(R.id.editText_title);
        editText_location = findViewById(R.id.editText_location);
        editText_notes= findViewById(R.id.editText_notes);
        initDatePicker();
        date_picker_btn = findViewById(R.id.date_picker_btn);
        date_picker_btn.setText(getTodayDate());

        initTimePicker();
        time_btn= findViewById(R.id.time_btn);

        memos= new Memos();
        try{
            memos= (Memos) getIntent().getSerializableExtra("old_memo");//same name in MainActivity
            editText_title.setText(memos.getTitle());
            editText_location.setText(memos.getLocation());
            editText_notes.setText(memos.getNotes());
            rememberDate();
            rememberTime();
            isOldNote=true;
        }catch (Exception e){
            e.printStackTrace();
        }

        date_picker_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                datePickerDialog.show();
            }
        });

        time_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                timePickerDialog.show();
                }
        });

        imageView_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String title = editText_title.getText().toString();
                String description = editText_notes.getText().toString();
                String location = editText_location.getText().toString();
                String date = getDate();
                time = getTime();

                String coordinates = getLatLongFromAddress(getApplicationContext(), location);

                if(title.isEmpty()){
                    Toast.makeText(MemosAddActivity.this,"Please add title",Toast.LENGTH_LONG).show();
                    return;
                }
                if(time_btn.getText() == "Select time" ){
                    Toast.makeText(MemosAddActivity.this,"Please select time event",Toast.LENGTH_LONG).show();
                    return;
                }
                if(coordinates == "no coordinates found"){ // MUST be the same in getLatLongFromAddress
                    Toast.makeText(MemosAddActivity.this,"Please add correct location",Toast.LENGTH_LONG).show();
                    return;
                }
                if(!isOldNote) {
                    memos = new Memos();
                }

                memos.setTitle(title);
                memos.setNotes(description);
                //memos.setDate(formatter.format(date));
                memos.setDate(date);
                memos.setTime(time);
                memos.setLocation(location);
                memos.setCoordinates(coordinates);
                Intent intent = new Intent();
                intent.putExtra("memo",memos); //needs serializable in Memos class, same name in MainActivity
                setResult(Activity.RESULT_OK,intent);
                finish();
            }
        });
    }

    private String getLatLongFromAddress(Context context, String strAddress) {
        Geocoder coder = new Geocoder(context);
        List<Address> addresses;
        String latLan= "";
        try {
            addresses = coder.getFromLocationName(strAddress, 5);
            Address bestMatch = (addresses.isEmpty() ? null : addresses.get(0));
            if (bestMatch != null) {
                latLan = new LatLng(bestMatch.getLatitude(), bestMatch.getLongitude()).toString();
            } //if invalid input location return nof found
            else {
                latLan = "no coordinates found"; // MUST be the same in the check of the save
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        if(latLan == ""){
            latLan = "no coordinates found";
        }
        return latLan;
    }

    private void rememberDate() {
        int[] dateL = dateToInt(memos.getDate());
        date_picker_btn.setText(memos.getDate());
        datePickerDialog.getDatePicker().updateDate(dateL[0],dateL[1],dateL[2]);
    }

    private void rememberTime() {
        int[] timeL = timeToInt(memos.getTime());
        time_btn.setText(memos.getTime());
        timePickerDialog.updateTime(timeL[0],timeL[1]);
        hour=timeL[0];
        minute= timeL[1];
    }

    private int[] timeToInt(String time) {
        String[] values = time.split(":");
        Integer h=Integer.parseInt(values[0]);
        Integer m= Integer.parseInt(values[1]);
        return new int[]{h,m};
    }

    private int[] dateToInt(String date) {
        String[] values = date.split(" ");
        int day = Integer.parseInt(values[0]);
        String stringMonth = values[1];
        int year = Integer.parseInt(values[2]);
        int month = monthToInt(stringMonth);
        //Log.v("MONTH CHECK:", String.valueOf(month));
        return new int[]{year,month,day};
    }


    private String getTime() {
        String h = new String(Integer.toString(hour));
        String m = new String(Integer.toString(minute));
        if(minute<10){
            m="0"+m;
        }
        return h+":"+m;
    }

    private void initTimePicker() {
        TimePickerDialog.OnTimeSetListener timeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                hour = selectedHour;
                minute = selectedMinute;
                time_btn.setText(String.format(Locale.getDefault(),"%02d:%02d",hour,minute));
            }
        };
        timePickerDialog= new TimePickerDialog(this,timeSetListener,hour,minute,true);
        timePickerDialog.setTitle("Selected time");
    }

    private void initDatePicker(){
        DatePickerDialog.OnDateSetListener dateSetListener = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                //month++;
                String date= makeDateString(day,month,year);
                date_picker_btn.setText(date);
            }
        };
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        datePickerDialog = new DatePickerDialog(this,dateSetListener,year,month,day);
        datePickerDialog.getDatePicker().setMinDate(System.currentTimeMillis()-1000);
    }

    private String getDate() {
        int day=datePickerDialog.getDatePicker().getDayOfMonth();
        int month= datePickerDialog.getDatePicker().getMonth();
        int year =datePickerDialog.getDatePicker().getYear();
        return makeDateString(day,month,year);

    }

    private String getTodayDate() {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        return makeDateString(day,month,year);
    }


    private String makeDateString(int day, int month, int year) {
        return day+" "+getMonthFormat(month)+" "+year;
    }

    private String getMonthFormat(int month) {
        switch (month){
            case 1:
                return "Jan";
            case 2:
                return "Feb";
            case 3:
                return "Mar";
            case 4:
                return "Apr";
            case 5:
                return "May";
            case 6:
                return "Jun";
            case 7:
                return "Jul";
            case 8:
                return "Aug";
            case 9:
                return "Sep";
            case 10:
                return "Oct";
            case 11:
                return "Nov";
            case 12:
                return "Dec";
            default:
                return "Jan";
        }
    }

    private int monthToInt(String stringMonth) {
        switch (stringMonth){
            case "Jan":
                return 1;
            case "Feb":
                return 2;
            case "Mar":
                return 3;
            case "Apr":
                return 4;
            case "May":
                return 5;
            case "Jun":
                return 6;
            case "Jul":
                return 7;
            case "Aug":
                return 8;
            case "Sep":
                return 9;
            case "Oct":
                return 10;
            case "Nov":
                return 11;
            case "Dec":
                return 12;
            default:
                return 1;
        }
    }
}