package com.example.memorandum;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.app.ActivityCompat;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.StaggeredGridLayoutManager;

import android.Manifest;
import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Build;
import android.os.Bundle;
import android.os.HandlerThread;
import android.os.Looper;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.SearchView;
import android.widget.Toast;

import com.example.memorandum.Adapters.MemosListAdapter;
import com.example.memorandum.Database.RoomDB;
import com.example.memorandum.Geofence.GeofenceHelper;
import com.example.memorandum.Models.Memos;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.Geofence;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.GeofencingRequest;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MainActivity extends AppCompatActivity implements PopupMenu.OnMenuItemClickListener{

    private static final int PERMISSIONS_FINE_LOCATION = 99;
    private static final int PERMISSIONS_BACKGROUND_LOCATION = 98;
    private static final float RADIUS = 150;
    RecyclerView recyclerView;
    MemosListAdapter memosListAdapter;
    List<Memos> memos = new ArrayList<>();
    List<String> memos_coordinates = new ArrayList<>();
    List<String> memos_titles = new ArrayList<>();
    List<String> memos_dates = new ArrayList<>();
    List<String> memos_times = new ArrayList<>();
    RoomDB database;
    FloatingActionButton fab_add,fab_map_view;
    SearchView searchView_home;
    Memos selectedMemo;
    ImageView imageView_all_memos,imageView_active_memos;
    boolean onlyActive=true;

    private GeofencingClient geofencingClient;
    private GeofenceHelper geofenceHelper;

    //Google's API for location services
    FusedLocationProviderClient fusedLocationProviderClient;

    //location request
    LocationRequest locationRequest;

    LocationCallback locationCallback;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recycler_home);
        fab_add= findViewById(R.id.fab_add);
        fab_map_view= findViewById(R.id.fab_map_view);
        searchView_home= findViewById(R.id.searchView_home);
        imageView_all_memos= findViewById(R.id.imageView_all_memos);
        imageView_active_memos= findViewById(R.id.imageView_active_memos);


        //set all proprierties of locationRequest
        locationRequest = new LocationRequest();
        locationRequest.setInterval(30000);
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_BALANCED_POWER_ACCURACY);

        locationCallback= new LocationCallback() {
            @Override
            public void onLocationResult(@NonNull LocationResult locationResult) {
                super.onLocationResult(locationResult);
                //save location
                Location location = locationResult.getLastLocation();
            }
        };

        database= RoomDB.getInstance(this);
        memos=database.mainDAO().getAll();

        updateRecycler(memos);
        updateGPS();
        geofencingClient = LocationServices.getGeofencingClient(this);
        geofenceHelper = new GeofenceHelper(this);

        if(onlyActive){
            filter_active();
        }

        searchView_home.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String s) {
                return false;
            }

            @Override
            public boolean onQueryTextChange(String s) {
                filter(s);
                return true;
            }
        });

        imageView_active_memos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"Only active memos",Toast.LENGTH_SHORT).show();
                onlyActive=true;
                updateView();
            }
        });

        imageView_all_memos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(MainActivity.this,"All memos",Toast.LENGTH_SHORT).show();
                onlyActive=false;
                updateView();
            }
        });

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this,MemosAddActivity.class);
                startActivityForResult(intent,101); //101 add memo, 102 modify memo
            }
        });

        fab_map_view.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy HH:mm");
                Date currentDate = new Date();

                memos_coordinates =database.mainDAO().getCoordinates();
                memos_titles =database.mainDAO().getTitles();
                memos_dates = database.mainDAO().getDates();
                memos_times = database.mainDAO().getTimes();

                ArrayList<String> memos_titles_array= new ArrayList<String>(memos_titles);
                ArrayList<String> memos_locations_array = new ArrayList<String>(memos_coordinates);
                ArrayList<String> memos_dates_array = new ArrayList<String>(memos_dates);
                ArrayList<String> memos_times_array = new ArrayList<String>(memos_times);

                Intent map_intent = new Intent(MainActivity.this,MapsActivity.class);

                map_intent.putExtra("memos_titles", memos_titles_array);
                map_intent.putExtra("memos_coordinates", memos_locations_array);
                map_intent.putExtra("memos_dates", memos_dates_array);
                map_intent.putExtra("memos_times", memos_times_array);
                startActivity(map_intent);
            }
        });


    }

    @Override
    protected void onPause() {
        super.onPause();
        fusedLocationProviderClient.removeLocationUpdates(locationCallback);
    }

    // -------------------------------------------------------------------------------------------------------------

    private void updateView() {
        updateRecycler(memos);
        if(onlyActive){
            filter_active();
        }
    }

    private void filter_active() {
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy HH:mm");
        Date currentDate = new Date();
        List<Memos> filteredList = new ArrayList<>();
        for(Memos singleMemo : memos){
                String sDate=singleMemo.getDate();
                String sTime= singleMemo.getTime();
                sDate = sDate+" "+sTime;
                try {
                    Date date =formatter.parse(sDate);
                    if(currentDate.before(date) && !singleMemo.isPinned()){
                        filteredList.add(singleMemo);
                        Log.v("MESSAGE LOCATION", "WE CAN ADD GEOFENECE");
                        addGeofence(getLatLngFromCoordinate(singleMemo.getCoordinates()),RADIUS,Integer.toString(singleMemo.getID()));
                    }

                }catch (Exception e){
                    e.printStackTrace();
                }
        }
        memosListAdapter.filterList(filteredList);
    }

    private void filter(String newText){
        List<Memos> filteredList = new ArrayList<>();
        for(Memos singleMemo : memos){
            if(singleMemo.getTitle().toLowerCase().contains(newText.toLowerCase())
            || singleMemo.getNotes().toLowerCase().contains(newText.toLowerCase())){
                filteredList.add(singleMemo);
            }
        }
        memosListAdapter.filterList(filteredList);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode==101){
            if(resultCode== Activity.RESULT_OK){
                Memos new_memos= (Memos) data.getSerializableExtra("memo"); //same name in MemosAddActivity
                database.mainDAO().insert(new_memos);
                memos.clear();
                memos.addAll(database.mainDAO().getAll());
                memosListAdapter.notifyDataSetChanged();
                updateView();
            }
        }
        else if (requestCode==102){
            if(resultCode== Activity.RESULT_OK){
                Memos new_memos = (Memos) data.getSerializableExtra("memo");
                database.mainDAO().update(new_memos.getID(), new_memos.getTitle(), new_memos.getNotes(),new_memos.getDate(),new_memos.getTime(), new_memos.getLocation(),new_memos.getCoordinates(), new_memos.isPinned());
                memos.clear();
                memos.addAll(database.mainDAO().getAll());
                memosListAdapter.notifyDataSetChanged();
                updateView();
            }
        }
    }

    private void updateRecycler(List<Memos> memos) {
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new StaggeredGridLayoutManager(2, LinearLayout.VERTICAL));

        memosListAdapter = new MemosListAdapter(MainActivity.this,memos,memosClickListener);
        recyclerView.setAdapter(memosListAdapter);
    }

    private final MemosClickListener memosClickListener= new MemosClickListener() {
        @Override
        public void onClick(Memos memos) {
            Intent intent= new Intent(MainActivity.this,MemosAddActivity.class);
            intent.putExtra("old_memo",memos); //same name in MemosAddActivity nel try
            startActivityForResult(intent,102);
        }

        @Override
        public void onLongClick(Memos memos, CardView cardView) {
            selectedMemo = new Memos();
            selectedMemo= memos;
            showPopup(cardView);
        }
    };

    private void showPopup(CardView cardView) {
        PopupMenu popupMenu = new PopupMenu(this,cardView);
        popupMenu.setOnMenuItemClickListener(this);
        popupMenu.inflate(R.menu.popup_menu);
        popupMenu.show();
    }

    @Override
    public boolean onMenuItemClick(MenuItem menuItem) {
        switch (menuItem.getItemId()){
            case R.id.pin:
                if(selectedMemo.isPinned()){
                    database.mainDAO().pin(selectedMemo.getID(),false);
                    Toast.makeText(MainActivity.this,"Unpinned",Toast.LENGTH_SHORT).show();
                }
                else{
                    database.mainDAO().pin(selectedMemo.getID(),true);
                    Toast.makeText(MainActivity.this,"Pinned",Toast.LENGTH_SHORT).show();
                }

                memos.clear();
                memos.addAll(database.mainDAO().getAll());
                memosListAdapter.notifyDataSetChanged();
                updateView();
                return true;
            case R.id.delete:
                database.mainDAO().delete(selectedMemo);
                memos.remove(selectedMemo);
                memosListAdapter.notifyDataSetChanged();
                updateView();
                Toast.makeText(MainActivity.this,"Memo deleted",Toast.LENGTH_SHORT).show();
                return true;
            default:
                return false;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode){
            case PERMISSIONS_FINE_LOCATION:
                if(grantResults.length > 0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    updateGPS();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"This app requires location permission to work proprerly",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
            case PERMISSIONS_BACKGROUND_LOCATION:
                if(grantResults.length > 0 && grantResults[0]==PackageManager.PERMISSION_GRANTED){
                    Log.v("MESSAGE LOCATION", "we have back location");
                    updateGPS();
                }
                else
                {
                    Toast.makeText(MainActivity.this,"This app requires background permission to work proprerly",Toast.LENGTH_SHORT).show();
                    finish();
                }
                break;
        }
    }

    private void updateGPS(){
        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(MainActivity.this);
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) == PackageManager.PERMISSION_GRANTED)
        {
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(this,new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    Log.v("MESSAGE LOCATION", "we have location");
                }
            });
        }
        else{
            if(Build.VERSION.SDK_INT >= Build.VERSION_CODES.M){
                if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION},PERMISSIONS_FINE_LOCATION);
                }
                else if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_BACKGROUND_LOCATION) != PackageManager.PERMISSION_GRANTED)
                {
                    requestPermissions (new String[]{Manifest.permission.ACCESS_BACKGROUND_LOCATION}, PERMISSIONS_BACKGROUND_LOCATION);
                }
            }
        }
    }

    private void addGeofence(LatLng latLng, float radius, String memos_id) {

        Geofence geofence = geofenceHelper.getGeofence(memos_id, latLng, radius, Geofence.GEOFENCE_TRANSITION_ENTER | Geofence.GEOFENCE_TRANSITION_DWELL | Geofence.GEOFENCE_TRANSITION_EXIT);
        GeofencingRequest geofencingRequest = geofenceHelper.getGeofencingRequest(geofence);
        PendingIntent pendingIntent = geofenceHelper.getPendingIntent();

        geofencingClient.addGeofences(geofencingRequest,pendingIntent)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        Log.v("GEOFENCE", "onSuccess: Geofence Added...");
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        String errorMessage = geofenceHelper.getErrorString(e);
                        Log.v("GEOFENCE", "onFailure: " + errorMessage);
                    }
                });
    }

    private LatLng getLatLngFromCoordinate (String coordinate){
        String[] string = coordinate.split(",");
        String str_lat = string[0].substring(10);
        String str_lon = string[1].substring(0, string[1].length() - 1);
        return getLatLngFromString(str_lat,str_lon);
    }

    private LatLng getLatLngFromString (String str_lat,String str_lon){
        double lat = Double.parseDouble(str_lat);
        double lon = Double.parseDouble(str_lon);
        return new LatLng(lat,lon);
    }

}