package com.example.memorandum;

import androidx.core.app.ActivityCompat;
import androidx.fragment.app.FragmentActivity;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Bundle;
import android.util.Log;

import com.example.memorandum.Models.Memos;
import com.google.android.gms.location.GeofencingClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.example.memorandum.databinding.ActivityMapsBinding;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private ActivityMapsBinding binding;
    private ArrayList<String> titles,dates,times;
    private ArrayList<LatLng> coordinates;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        Intent intent = getIntent();

        coordinates = getLatLongCoordinates(intent.getStringArrayListExtra("memos_coordinates"));
        titles = intent.getStringArrayListExtra("memos_titles");
        dates = intent.getStringArrayListExtra("memos_dates");
        times = intent.getStringArrayListExtra("memos_times");

        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(MapsActivity.this);

    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        SimpleDateFormat formatter = new SimpleDateFormat("dd MMM yyyy HH:mm");
        Date currentDate = new Date();
        for (int i = 0; i < coordinates.size(); i++) {
            if(isActive(currentDate,dates.get(i),times.get(i),formatter)){
                mMap.addMarker(new MarkerOptions().position(coordinates.get(i)).title(titles.get(i)));
            }
        }
        //display user location in the map
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
            mMap.setMyLocationEnabled(true);
        }

        // Add a marker in Sydney and move the camera
        //LatLng sydney = new LatLng(-34, 151);
        //mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney"));
        //mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));


    }

    //------------------------------------------------------------------------------------------------------------------

    private ArrayList<LatLng> getLatLongCoordinates(ArrayList<String> memos_coordinates) {
        ArrayList<LatLng> coordinates= new ArrayList<LatLng>();
        for(String coordinate : memos_coordinates){
            coordinates.add(getLatLngFromCoordinate(coordinate));
        }
        return coordinates;
    }

    private LatLng getLatLngFromCoordinate (String coordinate){
        String[] string = coordinate.split(",");
        String str_lat = string[0].substring(10);
        String str_lon = string[1].substring(0, string[1].length() - 1);
        return getLatLngFromString(str_lat,str_lon);
    }

    private LatLng getLatLngFromString (String str_lat,String str_lon){
        double lat = Double.parseDouble(str_lat);
        double lon = Double.parseDouble(str_lon);
        return new LatLng(lat,lon);
    }

    private boolean isActive(Date currentDate, String sDate, String sTime, SimpleDateFormat formatter) {
        sDate = sDate+" "+sTime;
        try {
            Date date =formatter.parse(sDate);
            if(currentDate.before(date) ){
                return true;
            }
        }catch (Exception e){
            e.printStackTrace();
        }
        return false;
    }

}