package com.example.memorandum.Geofence;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.example.memorandum.Notification.NotificationHelper;

public class GeofenceBroadcastReceiver extends BroadcastReceiver {

    private static final String TAG = "GeofenceBroadcastReceiver";

    @Override
    public void onReceive(Context context, Intent intent) {


        Log.v("GEOFENCE", "GEOFENCE TRIGGERED");
        //Toast.makeText(context, "Geofence triggered...", Toast.LENGTH_SHORT).show();


        NotificationHelper notificationHelper = new NotificationHelper(context);

        notificationHelper.sendHighPriorityNotification("ATTENTION", "You are close to an event place", intent);

    }
}
