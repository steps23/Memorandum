package com.example.memorandum.Database;

import static androidx.room.OnConflictStrategy.REPLACE;

import androidx.room.Dao;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;

import com.example.memorandum.Models.Memos;

import java.util.List;

@Dao
public interface MainDataAccesObj {

    @Insert(onConflict = REPLACE)
    void insert(Memos memos);

    @Query("SELECT * FROM memos ORDER BY date DESC")
    List<Memos> getAll();

    @Query("SELECT coordinates FROM memos WHERE pinned = false ORDER BY date DESC")
    List<String> getCoordinates();

    @Query("SELECT title FROM memos WHERE pinned = false ORDER BY date DESC")
    List<String> getTitles();

    @Query("SELECT date FROM memos WHERE pinned = false ORDER BY date DESC")
    List<String> getDates();

    @Query("SELECT time FROM memos WHERE pinned = false ORDER BY date DESC")
    List<String> getTimes();

    @Query("UPDATE memos SET title= :title, notes=:notes, date= :date , time= :time, location= :location,coordinates= :coordinates, pinned= :pinned WHERE ID= :id")
    void update(int id,String title,String notes,String date,String time,String location,String coordinates, boolean pinned);

    @Delete
    void delete(Memos memos);

    @Query("UPDATE memos SET pinned = :pin WHERE ID = :id")
    void pin(int id,boolean pin);

}