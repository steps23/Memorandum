package com.example.memorandum.Models;

import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

import java.io.Serializable;


@Entity(tableName="memos")
public class Memos implements Serializable {

    @PrimaryKey(autoGenerate = true)
    int ID=0;

    @ColumnInfo(name= "title")
    String title = "";

    @ColumnInfo(name="notes")
    String notes ="";

    @ColumnInfo(name="date")
    String date="";

    @ColumnInfo(name="time")
    String time="";

    @ColumnInfo(name="location")
    String location="";

    @ColumnInfo(name="coordinates")
    String coordinates="";

    @ColumnInfo(name="pinned")
    boolean pinned = false;

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getTime() { return time;}

    public void setTime(String time) { this.time = time;}

    public String getLocation() {return location;}

    public void setLocation(String location) {this.location = location;}

    public String getCoordinates() {return coordinates;}

    public void setCoordinates(String coordinates) {this.coordinates = coordinates;}

    public boolean isPinned() {
        return pinned;
    }

    public void setPinned(boolean pinned) {
        this.pinned = pinned;
    }

}