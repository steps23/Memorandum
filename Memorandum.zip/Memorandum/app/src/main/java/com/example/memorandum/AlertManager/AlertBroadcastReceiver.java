package com.example.memorandum.AlertManager;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

import com.example.memorandum.Notification.NotificationHelper;

public class AlertBroadcastReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {

        String memoTitle=intent.getStringExtra("memoTitle");
        String memoLocation=intent.getStringExtra("memoLocation");
        String memoTime= intent.getStringExtra("memoTime");

        NotificationHelper notificationHelper = new NotificationHelper(context);

        notificationHelper.sendHighPriorityNotification("ATTENTION", "it is time to do "+ memoTitle+" in "+ memoLocation+" at "+ memoTime, intent);
        //Toast.makeText(context, "ALERT triggered...", Toast.LENGTH_SHORT).show();
    }

}
